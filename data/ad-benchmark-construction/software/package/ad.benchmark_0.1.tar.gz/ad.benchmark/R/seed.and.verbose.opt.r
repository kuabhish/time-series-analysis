seed.and.verbose.opt <-
function() list(
	list(
        make_option(
            c(NULL,'--seed'),
            action = 'store',
            dest = 'seed', default = NULL,
            help = "You may set the random seed for the purposes of making runs reproducible."
        ),
    	function(opt) {
			if (!is.null(opt$seed)) {
				opt$seed <- as.numeric(opt$seed)
				if (!ck.int(opt$seed)) {
					exit("Random seed must be an integer.")
				}
				set.seed(opt$seed)
			}
			opt
		}

	),
	list(
        make_option(
            c('-v','--verbose'),
            action = 'store_true',
            dest = 'verbose', default = FALSE,
            help = "Standard verbose flag. Will print status updates as the algorithm runs."
        )
	)
)
