elem.fun.fac <-
function(f) axis.fun.fac(vec.fun.fac(f),2)
