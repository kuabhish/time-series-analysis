rank.ap <-
function(r) mean(1:length(r)/r)
