fast.klr.cv <-
function(X,y,n.folds=5,C.vec=10^(-3:3),eps=0.001,verbose=F) {
	n <- length(y)
	nn <- sum(y>0)
	na <- sum(y<0)
	fold.size <- ceiling(n/n.folds)
	nom.size <- ceiling(fold.size*nn/n)
	anom.size <- fold.size-nom.size
	nom.samp <- sample(nn)
	anom.samp <- sample(na)
	if (length(C.vec)>1) {
		if (n.folds>1) {
			C.score <- matrix(-Inf,ncol=length(C.vec),nrow=n.folds)
		} else {
			mdls <- list()
			C.score <- rep(-Inf,length(C.vec))
		}
		for (i in 1:length(C.vec)) {
			print.time.if.verbose(paste0('Testing C = ',C.vec[i]),verbose,{
				if (n.folds>1) {
					for (j in 1:n.folds) {
						print.time.if.verbose(paste0('Fold #',j),verbose,{
							fold.mask <- c(which(y>0)[((j-1)*nom.size+1):min(nn,j*nom.size)],which(y<0)[((j-1)*anom.size+1):min(na,j*anom.size)])
							m <- fast.klr.model(X[-fold.mask,],y[-fold.mask],
												C=C.vec[i],eps=eps,verbose=verbose)
							print.time.if.verbose('Scoring ...',verbose,{
								C.score[j,i] <- ll.score(m$resp.f(X[fold.mask,]),y[fold.mask])
								print(paste0('ll.score = ',C.score[j,i]))
							})
						})
					}
				} else {
					mdls[[i]] <- fast.klr.model(X,y,C=C.vec[i],eps=eps,verbose=verbose)
					print.time.if.verbose('Scoring ...',verbose,{
						C.score[i] <- ll.score(mdls[[1]]$trn.response,y)
						print(paste0('ll.score = ',C.score[i]))
					})
				}
			})
		}
		if (n.folds>1) {
			C <- C.vec[which.max(apply(C.score,2,sum))]
		}
	} else {
		C <- C.vec[1]
	}
	if (n.folds>1 | length(C.vec)<2) {
		fast.klr.model(X,y,C,eps,verbose)
	} else {
		mdls[[which.max(C.score)]]
	}
}
