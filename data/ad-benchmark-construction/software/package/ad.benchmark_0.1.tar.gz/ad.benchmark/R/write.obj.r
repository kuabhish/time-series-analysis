write.obj <-
function(obj,fname) {
	save(obj,file=fname)
}
