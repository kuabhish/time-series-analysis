nu <-
function(K,i,j) K[i,i]-2*K[i,j]+K[j,j]
