expected.random.ap <-
function(n.anom,n.norm) {
	n <- n.anom + n.norm
	sum(sapply(1:n.anom,function(i) {
		slice <- i:(n.norm+i)
		sum(dhyper(i,n.anom,n.norm,slice)*(i/slice)^2)
	}))/n.anom
}
