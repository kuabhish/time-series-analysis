class.weights <-
function(y) {
	cw <- rep(1,length(y))
	cw[y==1] <- sum(y!=1)/sum(y==1)
	cw/sum(cw)
}
