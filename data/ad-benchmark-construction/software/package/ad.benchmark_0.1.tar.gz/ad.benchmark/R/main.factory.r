main.factory <-
function(opts,main.code) {
	opt <- parse.and.validate.zipped.args(opts)
	attach(opt)
	if (verbose) print("Arguments validated.")

	main.code

	if(!is.null(warnings())) print(warnings())
}
