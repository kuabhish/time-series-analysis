mach.omg <-
function() {
	eps <- 1
	while(1-eps/2 < 1) eps <- eps/2
	1-eps
}
