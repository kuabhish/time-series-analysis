schoose <-
function(n,k) choose(pmax(0,n),k)
