log.add <-
function(l1,l2) {
	if (l1 == -Inf) l2
	else log(1+exp(l2-l1))+l1
}
