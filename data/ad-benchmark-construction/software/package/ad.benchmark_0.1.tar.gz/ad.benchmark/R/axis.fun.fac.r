axis.fun.fac <-
function(f,a) function(x) {
	if (!is.null(dim(x))) {
		apply(x,a,f)
	} else {
		f(x)
	}
}
