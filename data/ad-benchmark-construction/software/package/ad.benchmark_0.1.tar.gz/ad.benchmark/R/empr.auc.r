empr.auc <-
function(nn,na,nsamp=10000) sapply(1:nsamp,function(i) sample.auc(nn,na)) 
