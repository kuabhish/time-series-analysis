is.file <-
function(f.name) {
    file.exists(f.name) & !is.dir(f.name)
}
