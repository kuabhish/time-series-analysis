emp.auc.quant <- 
function(nn,na,q=c(0.9,0.95,0.99,0.999),nsamp=10000) {
	size <- max(length(nn),length(na))
	idx <- 1:size
	nn <- rep(nn,size)
	na <- rep(na,size)
	t(sapply(idx,function(i) {print(i);quantile(empr.auc(nn[i],na[i],nsamp),probs=q)}))
}
