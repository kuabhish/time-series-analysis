is.dir <-
function(dir.name) {
    file.exists(file.path(dir.name,"."))
}
