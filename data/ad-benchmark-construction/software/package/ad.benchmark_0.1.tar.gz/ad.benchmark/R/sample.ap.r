sample.ap <-
function(nn,na) {
	s<-sample(nn+na,na)
	s<-s[order(s)]
	mean(1:na/s)
}

