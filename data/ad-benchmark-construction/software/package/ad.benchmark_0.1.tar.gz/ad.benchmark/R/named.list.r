named.list <-
function(...) {
    vals <- list(...)

    if (is.null(names(vals))) {
        missing_names <- rep(TRUE, length(vals))
    } else {
        missing_names <- names(vals) == ""
    }
    if (any(missing_names)) {
        names <- vapply(substitute(list(...))[-1], deparse, character(1))
        names(vals)[missing_names] <- names[missing_names]
    }

    vals
}
