benchmark.klr.diff.main <-
function() main.factory(benchmark.klr.diff.opt(),{
	ground.truth <- response
	y <- 2*(ground.truth=='nominal')-1

	if (nrow(data)<=max.size) {
		print.time.if.verbose('building klr model',verbose,{
			m <- fast.klr.cv(data,y,n.folds=n.folds,C.vec=C.vec,eps=eps,verbose=verbose)
		})
		print.time.if.verbose('scoring points',verbose,{
			diff.score <- m$trn.response
			diff.score[y==1] <- 1-diff.score[y==1]
		})
		if (exists('meta.data')) {
			outd <- data.frame(meta.data,diff.score,ground.truth,data)
		} else {
			outd <- data.frame(diff.score,ground.truth,data)
		}
		make.csv(outd,out.name)
	} else {
		print.time.if.verbose('building klr model',verbose,{
			m <- fast.klr.sub(data,y,s.size=min(max.size,ceiling((nrow(data)*(n.folds-1))/n.folds)),n.samp=2*n.folds,C.vec=C.vec,eps=eps,verbose=verbose)
		})
		print.time.if.verbose('scoring points',verbose,{
			i <- 1
			while (i <= nrow(data)) {
				print.time.if.verbose(paste0('Scoring from point: ',i),verbose,{
					j <- min(i+999,nrow(data))
					diff.score <- m$resp.f(data[i:j,])
					diff.score[y[i:j]==1] <- 1-diff.score[y[i:j]==1]
					if (exists('meta.data')) {
						outd <- data.frame(meta.data[i:j,],diff.score,ground.truth[i:j],data[i:j,])
						colnames(outd) <- c(colnames(meta.data),'diff.score','ground.truth',colnames(data))
					} else {
						outd <- data.frame(diff.score[i:j],ground.truth[i:j],data[i:j,])
						colnames(outd) <- c('diff.score','ground.truth',colnames(data))
					}
					if (i==1) {
						make.csv(outd,out.name)
					} else {
						tmp.name <- paste0('tmp.',Sys.getpid())
						write.table(outd,tmp.name,quote=F,col.names=F,row.names=F,sep=',')
						system(paste0('cat ',tmp.name,' >> ',out.name))
						system(paste0('rm -f ',tmp.name))
					}
				})
				i <- j+1
			}
		})
	}
})
