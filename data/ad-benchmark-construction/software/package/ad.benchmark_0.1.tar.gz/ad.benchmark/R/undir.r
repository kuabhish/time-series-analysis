undir <-
function(name="") {
	if (is.null(name)) name <- ""
	name <- file.path('.',name)
	ret <- strsplit(name,.Platform$file.sep)[[1]]
	ret[length(ret)]
}
