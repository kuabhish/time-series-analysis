parse.and.validate.args <-
function(option.list,validation.functions) {
	opt <- parse_args(OptionParser(option_list=option.list))
	for (fn in validation.functions) {
		opt <- fn(opt)
	}
	opt
}
