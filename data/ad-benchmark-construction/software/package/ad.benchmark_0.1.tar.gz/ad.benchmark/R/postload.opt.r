postload.opt <-
function(opts,post.fn=function(opt){opt},meta.default=NULL) {
	preproc.opts <- preproc.opt(meta.default)
	preproc.opts[[2]][[2]] <- post.fn
	list.c(opts,preproc.opts)
}
