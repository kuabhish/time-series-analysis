phi__ <-
function(nu,a_i,a_j,C) nu+(G__(a_i/C)+G__(a_j/C))/C
