mean.without <-
function(u,n,x) (u*n-x)/(n-1)
