multiclass.ground.truth <- function(response,data,verbose) {
	response <- as.factor(response)
	print.time.if.verbose("Training RF model.",verbose,{
		rf <- randomForest(data,response,ntree=1000,mtry=1)
	})
	print.time.if.verbose("Getting RF confusion mass.",verbose,{
		rpr <- predict(rf,data,type="prob")
	})
	print.time.if.verbose("Summing confusion masses.",verbose,{
	#Not quite the same as simply computing the off-diagonal of a confusion matrix.
	#Even non-confused points might contain some signal about confusion between points. 
	#Abstractly, cm is a fully connected graph between classes with confusion mass
	#as edge weights.
		cm <- matrix(0,nrow=length(levels(response)),ncol=length(levels(response)))
		for (i in 1:nrow(data)) {
			target <- as.numeric(response[i])
			for (j in 1:ncol(rpr)) {
				if (j != target) {
					cm[target,j] <- cm[target,j] + rpr[i,j]
					cm[j,target] <- cm[target,j]
				}
			}
		}
	})
	#Abstractly, an MST of this graph can inform a confusing partition of the classes.
	#The MST is two-colored (classA and classB) as it is built.
	print.time.if.verbose("Splitting classes",verbose,{
		maxv <- apply(cm,1,max)
		cands <- which(maxv==max(maxv))
		classA <- cands[1]
		classB <- cands[2]
		taken <- cands
		while (length(taken) < length(levels(response))) {
			for (t in taken) for (t_ in taken) cm[t,t_] <- 0
			maxv <- apply(cm[taken,],1,max)
			target <- taken[which(maxv==max(maxv))[1]]
			cand <- which(cm[target,]==max(cm[target,]))
			if (target %in% classA) {
				classB <- c(classB,cand)
			} else {
				classA <- c(classA,cand)
			}
			taken <- c(taken,cand)
		}
	})

	ground.truth <- as.numeric(response) %in% classA
	binary.ground.truth(ground.truth,data,verbose)
}
