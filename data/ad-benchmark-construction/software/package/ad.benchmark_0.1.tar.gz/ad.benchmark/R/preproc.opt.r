preproc.opt <-
function(meta.default=NULL) list(
	list(	
        make_option(
            c('-m','--meta.col'),
            action = 'store',
            dest = 'meta.cols', default = meta.default,
            help = "You may specify a comma-separated list of columns to leave intact as meta-data. Default is %default."
        ),
		function(opt) {
			print.time.if.verbose("Loading data set ...",opt$verbose,opt$data <- read.csv(opt$in.name))
			opt
		}
	),
	list(
        make_option(
            c('-r','--rows.rm'),
            action = 'store',
            dest = 'rm.rows', default = NULL,
            help = "You may provide a comma-separated list of rows to remove from the data set."
        )
	),
	list(
        make_option(
            c('-c','--cols.rm'),
            action = 'store',
            dest = 'rm.cols', default = NULL,
            help = "You may provide a comma-separated list of columns to remove from the data set."
        ),
		function(opt) {
			print.time.if.verbose("Preprocessing data ...",opt$verbose,{
				prpr <- preproc(opt$data,opt$meta.cols,opt$rm.rows,opt$rm.cols,TRUE)
				opt$data <- prpr$data
				opt$meta.data <- prpr$meta.data
			})
			opt
		}
	)
)
