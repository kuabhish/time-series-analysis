benchmark.preproc.main <-
function() main.factory(benchmark.preproc.opt(),{
	print.time.if.verbose('Removing non-numeric data.',verbose,{
		to.rm <- c()
		for (i in 1:ncol(data))
			if (class(data[,i])!='numeric' & class(data[,i])!='integer')
				to.rm <- c(to.rm,i)
		if (!is.null(to.rm))
			data <- data[,-to.rm]
		cn <- colnames(data)
	})

	print.time.if.verbose('Translating by mean and scaling by sd.',verbose,{
		mu.vec <- apply(data,2,mean)
		sd.vec <- apply(data,2,sd)
		data <- t((t(data)-mu.vec)/sd.vec)
		colnames(data) <- cn
	})

	print.time.if.verbose(paste0('Converting ',origin,' response to ground truth.'),verbose,{
		ground.truth <- get(paste0(origin,'.ground.truth'))(response,data,verbose)
	})

	point.id <- paste0(motherset,'_point_',formatC(1:nrow(data),digits=nchar(as.character(nrow(data)))-1,flag='0')) 
	original.label <- response
	motherset <- rep(motherset,nrow(data))
	origin <- rep(origin,nrow(data))
	
	if (!exists('meta.data')) {
		meta.data <- data.frame(point.id,motherset,origin,original.label,ground.truth)
	} else {
		meta.data <- data.frame(point.id,motherset,origin,original.label,meta.data,ground.truth)
	}

	data <- data.frame(meta.data,data)

	make.csv(data,out.name)
})
