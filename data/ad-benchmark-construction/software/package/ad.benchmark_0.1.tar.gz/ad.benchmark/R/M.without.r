M.without <-
function(M,u,n,x) {
	u_ <- mean.without(u,n,x)
	M - (x-u)*(x-u_)
}
