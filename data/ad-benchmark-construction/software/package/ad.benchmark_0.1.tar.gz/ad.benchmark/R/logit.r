logit <-
function(x) pmax(pmin(39,log(x/(1-x))),-39)
