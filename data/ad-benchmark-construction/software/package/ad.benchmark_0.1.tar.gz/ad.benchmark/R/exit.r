exit <-
function(str=NULL) {
    if (!is.null(str))
        print(str)
    quit("no",1,FALSE)
}
