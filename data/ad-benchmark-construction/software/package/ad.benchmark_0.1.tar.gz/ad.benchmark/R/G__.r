G__ <-
function(x) 1/(x*(1-x))
