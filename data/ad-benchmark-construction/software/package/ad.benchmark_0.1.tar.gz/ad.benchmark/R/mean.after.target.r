mean.after.target <-
function(u,n,t) t*(n+1)-(u*n)
