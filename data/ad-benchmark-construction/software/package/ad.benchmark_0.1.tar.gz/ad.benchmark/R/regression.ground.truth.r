regression.ground.truth <- function(response,data,verbose) {
	if (length(unique(response)) < 3 | (class(response)!='numeric' & class(response)!='integer')) {
		exit('Regression response is either not numeric or too sparse.')
	}
	med <- median(response)
	low.mask <- response < med
	high.mask <- response > med
	low.var <- sum(diag(var(data[low.mask,])))
	high.var <- sum(diag(var(data[high.mask,])))
	if (low.var < high.var) {
		nom.mask <- response <= med
	} else if (low.var >= high.var) {
		nom.mask <- response >= med
	}
	ground.truth <- as.factor(nom.mask)
	levels(ground.truth) <- c('anomaly','nominal')
	ground.truth
}
