pad.dim <-
function(d,a) floor((a*(d^0.5))^2-d)
