preproc <- function(data,meta.cols=NULL,rm.rows=NULL,rm.cols=NULL,rm.sparse=FALSE) {
    if (!is.null(rm.rows)) {
        rm.rows <- comma.to.numbers(rm.rows)
        if (sum(rm.rows < 1) > 0 | sum(rm.rows > nrow(data)) > 0)
            exit("Asked to remove rows that do not exist.")
    } else {
        rm.rows <- c()
    }
    if (!is.null(rm.cols)) {
        rm.cols <- comma.to.numbers(rm.cols)
        if (sum(rm.cols < 1) > 0 | sum(rm.cols > ncol(data)) > 0)
            exit("Asked to remove cols that do not exist.")
    } else {
        rm.cols <- c()
    }

    if (!is.null(meta.cols)) {
        meta.cols <- comma.to.numbers(meta.cols)	
        if (sum(meta.cols < 1) > 0 | sum(meta.cols > ncol(data)) > 0)
            exit("Meta data columns do not exist.")
		meta.data <- data.frame(data[,meta.cols])
		colnames(meta.data) <- colnames(data)[meta.cols]
    } else {
		meta.cols <- c()
		meta.data <- c()
	}

	rm.cols <- c(rm.cols,meta.cols)

    if (!is.null(rm.rows)) {
        rm.rows <- unique(rm.rows)
        data <- data[-rm.rows,]
    }
    if (!is.null(rm.cols)) {
        rm.cols <- unique(rm.cols)
        data <- data[,-rm.cols]
    }

	if (rm.sparse) {
		rm.cols <- c()
		for (i in 1:ncol(data)) {
			nu <- length(unique(data[,i]))
			if (nu <= 1) {
				rm.cols <- c(rm.cols,i)
			}
		}
		if (!is.null(rm.cols)) {
			data <- data[,-rm.cols]
		}
	}

    named.list(data,meta.data)
}
