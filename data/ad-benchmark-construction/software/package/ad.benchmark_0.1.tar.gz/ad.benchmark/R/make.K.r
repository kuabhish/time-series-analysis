make.K <-
function(X) {
	D <- dist(X)
	K <- as.matrix(D)^2
	diag(K) <- Inf
	sigma.cans <- apply(K,2,min)
	sigma.squared <- median(sigma.cans[sigma.cans!=0])
	diag(K) <- 0
	dist.f <- function(d) exp(-d/(2*sigma.squared))
	k.f <- function(x,y) {
		t(if (!is.null(dim(x))) {
			apply(x,1,function(a) k.f(a,y))
		} else if (!is.null(dim(y))) {
			apply(y,1,function(b) k.f(x,b))
		} else {
			dist.f(sum((x-y)^2))
		})
	}
	K <- dist.f(K)
	named.list(K,sigma.squared,dist.f,k.f)
}
