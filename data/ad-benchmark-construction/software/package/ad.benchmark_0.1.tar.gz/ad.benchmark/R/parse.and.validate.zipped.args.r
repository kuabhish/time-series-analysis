parse.and.validate.zipped.args <-
function(zipped.args) {
	option.list <- lapply(zipped.args,function(o) o[[1]])
	validation.functions <- lapply(zipped.args,function(o) if (length(o)>1) o[[2]] else function(opt) opt)
	parse.and.validate.args(option.list,validation.functions)
}
