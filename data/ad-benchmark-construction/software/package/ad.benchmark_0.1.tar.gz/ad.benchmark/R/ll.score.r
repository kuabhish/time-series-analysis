ll.score <-
function(psc,y,cw=class.weights(y)) {
	psc <- psc*y
	psc[y<0] <- psc[y<0]+1
	sum(cw*log(psc))
}
