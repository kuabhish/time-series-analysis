sample.auc <-
function(nn,na) sum(((sample(0:nn,na,replace=T))/nn)/na)
