npr <-
function(k,a,b=a) {
	schoose((a:b)+k-1,k-1)
}
