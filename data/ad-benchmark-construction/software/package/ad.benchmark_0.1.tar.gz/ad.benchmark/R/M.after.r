M.after <-
function(M,u,n,x) {
	u_ <- mean.after(u,n,x)
	M + (x-u)*(x-u_)
}
