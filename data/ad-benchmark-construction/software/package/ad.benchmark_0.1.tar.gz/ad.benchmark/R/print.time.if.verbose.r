print.time.if.verbose <-
function(str=NULL,verbose,code) {
    if (verbose & !is.null(str)) {
        print(str)
    }
    t <- system.time(ret <- code)
    if (verbose) {
        print(t)
    }
    ret
}
