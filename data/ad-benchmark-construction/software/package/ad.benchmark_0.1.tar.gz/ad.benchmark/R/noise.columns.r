noise.columns <-
function(d,r,c) if (c>0) sapply(1:c,function(i) {
	rsamp<-sample(nrow(d),r,replace=T)
	csamp<-sample(ncol(d),1)
	d[rsamp,csamp]
}) else c()
