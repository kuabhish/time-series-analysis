unpad.dim <-
function(d,a) ceiling(d/(a^2))
