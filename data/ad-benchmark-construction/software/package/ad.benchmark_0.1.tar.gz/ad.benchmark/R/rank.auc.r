rank.auc <-
function(r,n) mean(n-r+1-length(r):1)/(n-length(r))
