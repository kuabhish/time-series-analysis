mach.eps <- function() {
	eps <- 1
	while(eps/2 > 0) eps <- eps/2
	eps
}
