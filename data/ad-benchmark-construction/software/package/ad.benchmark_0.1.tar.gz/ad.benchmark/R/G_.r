G_ <-
function(x) log(x/(1-x))
