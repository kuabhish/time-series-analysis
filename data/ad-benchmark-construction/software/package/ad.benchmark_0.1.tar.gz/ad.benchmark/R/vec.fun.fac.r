vec.fun.fac <-
function(f) function(x) {
	if (length(x) > 1) {
		sapply(x,f)
	} else {
		f(x)
	}
}
