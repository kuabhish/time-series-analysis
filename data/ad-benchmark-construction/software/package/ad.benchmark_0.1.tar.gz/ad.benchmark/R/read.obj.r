read.obj <-
function(fname) {
	load(fname)
	rm(fname)
	ret <- as.list(environment())
	if (length(ret) < 2) ret <- ret[[1]]
	ret
}
