comma.to.numbers <-
function(str) {
    as.numeric(comma.split(str))
}
