comma.split <-
function(str) {
    strsplit(str,",")[[1]]
}
