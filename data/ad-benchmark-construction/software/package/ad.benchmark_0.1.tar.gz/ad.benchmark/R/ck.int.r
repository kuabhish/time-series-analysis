ck.int <-
function(i) {
    as.integer(i)==i
}
