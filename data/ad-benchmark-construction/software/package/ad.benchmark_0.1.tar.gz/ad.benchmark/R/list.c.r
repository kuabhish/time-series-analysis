list.c <-
function(...) {
	ret <- list()
	for (s.list in list(...)) {
		for (o in s.list) {
			ret[[length(ret)+1]] <- o
		}
	}
	ret
}
