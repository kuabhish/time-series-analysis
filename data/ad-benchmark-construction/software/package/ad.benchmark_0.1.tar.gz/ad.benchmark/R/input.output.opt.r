input.output.opt <-
function() list(
	list(	
        make_option(
            c('-i','--input'),
            action = 'store',
            dest = 'in.name', default = NULL,
            help = "Path to the input file. (Required)."
        ),
    	function(opt) {
			if (is.null(opt$in.name))
				exit("Providing an input file with '--input' option is required. Use option '--help' for more details.")
		   
			if (!is.file(opt$in.name))
				exit("Provided input file does not exist or is not a regular file.")

			opt
		}
	),
	list(
        make_option(
            c('-o','--output'),
            action = 'store',
            dest = 'out.name', default = NULL,
            help = "Path to the output file. (Required)."
        ),
    	function(opt) {
			if (is.null(opt$out.name))
				exit("Providing an output file with '--output' option is required. Use option '--help' for more details.")

			if (is.dir(opt$out.name))
				exit("Provided output file is a directory.")
	
			opt
		}
	)
)
