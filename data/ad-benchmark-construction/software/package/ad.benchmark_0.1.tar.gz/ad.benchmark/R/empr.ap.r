empr.ap <-
function(nn,na,nsamp=10000) sapply(1:nsamp,function(i) sample.ap(nn,na)) 
