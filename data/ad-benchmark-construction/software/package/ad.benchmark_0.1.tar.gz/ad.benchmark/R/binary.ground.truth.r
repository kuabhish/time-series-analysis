binary.ground.truth <- function(response,data,verbose) {
	ground.truth <- as.factor(response)
	if (length(levels(ground.truth))!=2)
		exit('Binary response has more than two responses.')
	one.mask <- ground.truth==levels(ground.truth)[1]
	two.mask <- ground.truth==levels(ground.truth)[2]
	if (sum(one.mask) < sum(two.mask)) {
		levels(ground.truth) <- c('anomaly','nominal')
	} else if (sum(one.mask) > sum(two.mask)) {
		levels(ground.truth) <- c('nominal','anomaly')
	} else if (sum(one.mask) == sum(two.mask)) {
		one.var <- sum(diag(var(data[one.mask,])))
		two.var <- sum(diag(var(data[two.mask,])))
		if (one.var < two.var) {
			levels(ground.truth) <- c('nominal','anomaly')
		} else if (one.var >= two.var) {
			levels(ground.truth) <- c('anomaly','nominal')
		}
	}
	ground.truth
}
